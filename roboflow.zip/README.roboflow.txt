
car - v1 2021-06-28 1:16pm
==============================

This dataset was exported via roboflow.ai on June 28, 2021 at 10:28 AM GMT

It includes 35 images.
Car-detect are annotated in Tensorflow TFRecord (raccoon) format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* 50% probability of horizontal flip
* Randomly crop between 0 and 20 percent of the image
* Random brigthness adjustment of between -25 and +25 percent


